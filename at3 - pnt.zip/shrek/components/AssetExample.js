import React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}></Text>
      <View style={styles.imageContainer}>
        <Image style={styles.logo} source={require('../assets/shrek.png')} />
        <Image style={styles.logo} source={require('../assets/shre.png')} />
      </View>
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Assistir</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
     backgroundColor:'green',
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  imageContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  logo: {
    height: 108,
    width: 130,
    margin: 10,
  },
  button: {
    backgroundColor: 'purple',
    padding: 10,
    marginTop: 20,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
